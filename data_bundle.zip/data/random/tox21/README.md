# Tox21 多任务毒性数据

数据来源：DeepChem/MoleculeNet 的公开 Tox21 CSV。

- 原始压缩文件：项目根目录 `tox21.csv.gz`
- `train.csv`：训练集
- `valid.csv`：验证集
- `test.csv`：测试集
- `split_summary.json`：每个划分、每个 assay 的标签数、缺失数、阳性数和阴性数
- `prepare_tox21.py`：可复现划分脚本（项目根目录）

## 划分信息

- 总计 7,831 条记录，12 个毒性 assay。
- 比例为 80%/10%/10%，随机种子为 42。
- 完全相同的 SMILES 保持在同一个划分中。
- 缺失标签保留为空值；训练时必须通过标签 mask 忽略，不能当作阴性。

DeepChem 的 Tox21 loader 将 random split 列为推荐方案，因此该划分适用于先调通模型和复现基准。若用于正式论文的结构泛化结论，还应另做 Bemis–Murcko scaffold split，并将它作为主要或补充评估；不要把 random split 分数与 scaffold split 分数直接比较。

## 建议模型配置

检测到本机为 NVIDIA GeForce RTX 4060 Laptop GPU，显存 8 GiB（检测时可用约 6.4 GiB）。适合训练中小型 2D GIN/MPNN 和分层注意力模型。建议先从 batch size 32、隐藏维度 128、2–3 层图编码器开始；若显存足够再尝试 batch size 64 或隐藏维度 256。原始数据很小，CPU 预处理也可完成。

## 来源

https://deepchemdata.s3-us-west-1.amazonaws.com/datasets/tox21.csv.gz
